"""Solar models."""
