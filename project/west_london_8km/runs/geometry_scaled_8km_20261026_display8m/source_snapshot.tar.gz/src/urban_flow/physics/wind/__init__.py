"""Wind model implementations."""
