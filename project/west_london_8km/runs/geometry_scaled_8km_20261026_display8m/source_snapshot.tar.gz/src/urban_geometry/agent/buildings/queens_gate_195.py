"""195 Queen Gate only: EA-informed layered roof, explicitly estimated residential elevation."""
import math
ROOF=[[(493.2504560148809, 34.391068113036454, 22.2), (491.66154051886406, 44.23981411010027, 22.2), (494.8273617893156, 44.708140477354675, 27.799999999999997)], [(494.8273617893156, 44.708140477354675, 27.799999999999997), (496.41780667376327, 34.84991470731129, 27.799999999999997), (493.2504560148809, 34.391068113036454, 22.2)], [(496.41780667376327, 34.84991470731129, 27.799999999999997), (494.8273617893156, 44.708140477354675, 27.799999999999997), (501.55473198902513, 45.70333400777028, 27.79999999999999)], [(501.55473198902513, 45.70333400777028, 27.79999999999999), (503.1484268238883, 35.82496372014531, 27.799999999999965), (496.41780667376327, 34.84991470731129, 27.799999999999997)], [(503.1484268238883, 35.82496372014531, 27.799999999999965), (501.55473198902513, 45.70333400777028, 27.79999999999999), (507.4906468711217, 46.58144594637228, 23.000000000000025)], [(507.4906468711217, 46.58144594637228, 23.000000000000025), (509.0872093092927, 36.68530108441062, 23.000000000000004), (503.1484268238883, 35.82496372014531, 27.799999999999965)], [(512.9379747475032, 47.38728021737188, 22.999999999999996), (520.5538375195719, 48.67192238010466, 22.999999999999996), (521.5071766584879, 43.05218342039734, 22.999999999999996)], [(508.69868740288075, 40.89924624655396, 22.999999999999996), (509.48440131230745, 36.74284134991467, 22.999999999999996), (509.0872093092927, 36.68530108441062, 23.000000000000004)], [(508.69868740288075, 40.89924624655396, 22.999999999999996), (512.9379747475032, 47.38728021737188, 22.999999999999996), (521.5071766584879, 43.05218342039734, 22.999999999999996)], [(508.69868740288075, 40.89924624655396, 22.999999999999996), (509.0872093092927, 36.68530108441062, 23.000000000000004), (507.4906468711217, 46.58144594637228, 23.000000000000025)], [(512.9379747475032, 47.38728021737188, 22.999999999999996), (508.69868740288075, 40.89924624655396, 22.999999999999996), (507.4906468711217, 46.58144594637228, 23.000000000000025)]]
def build(ctx,feature):
 base=float(feature.get('base_m',0));ring=feature['geometry'][0]['outer'];a,b=ring[:2];L=math.dist(a,b);ux,uy=(b[0]-a[0])/L,(b[1]-a[1])/L
 def rh(x,y):
  v=-(x-a[0])*uy+(y-a[1])*ux
  return 22.2+5.6*max(0,min(1,v/3.2))-4.8*max(0,min(1,(v-10)/6))
 plaster=ctx.material('195 estimated pale stucco',(.73,.71,.65),.86)
 trimat=ctx.material('195 estimated pale dressings',(.79,.77,.71),.72)
 slate=ctx.material('195 dark slate roof',(.12,.14,.15),.84)
 glass=ctx.material('195 blue grey glass',(.14,.20,.22),.2,0,.28)
 iron=ctx.material('195 painted black metal',(.025,.03,.03),.44,.65)
 timber=ctx.material('195 estimated dark timber',(.09,.045,.027),.69)
 stone=ctx.material('195 estimated threshold stone',(.52,.50,.45),.87)
 panel=ctx.material('195 estimated lighter timber panels',(.16,.09,.045),.70)
 wall=ctx.mesh('complete footprint party walls and real openings');roof=ctx.mesh('EA layered continuous roof');windows=ctx.mesh('estimated sash windows');details=ctx.mesh('simplified frontage bands and portico');entry=ctx.mesh('estimated street door and low threshold')
 for tr in ROOF:roof.face([(x,y,base+z) for x,y,z in tr],slate)
 entrances=[]
 for ei,(A,B) in enumerate(zip(ring,ring[1:]+ring[:1])):
  ll=math.dist(A,B);tx,ty=(B[0]-A[0])/ll,(B[1]-A[1])/ll;nx,ny=ty,-tx
  def p(s,d,z):return(A[0]+tx*s+nx*d,A[1]+ty*s+ny*d,base+z)
  def bx(m,s,d,z,w,dep,hh,mat):m.box(*p(s,d,z),w,dep,hh,mat,math.atan2(ty,tx))
  apertures=[]
  if ei in [0,2]:
   count=3 if ei==0 else 1
   for k in range(count):
    c=ll*(k+.5)/count
    for row,lo in enumerate([.8,4.7,8.5,12.3,16.1,19.6]):
     hi=lo+(2.7 if row<4 else 2.0);door=ei==0 and k==0 and row==0
     if hi>min(rh(*A),rh(*B))-.4:continue
     apertures.append((c-(.79 if door else .67),c+(.79 if door else .67),.08 if door else lo,3.4 if door else hi,door))
  xs=[0,ll]+[xx for op in apertures for xx in op[:2]]
  # Split boundary wherever a roof plane changes so all sloping wall closures remain planar.
  va=-(A[0]-a[0])*uy+(A[1]-a[1])*ux;vb=-(B[0]-a[0])*uy+(B[1]-a[1])*ux
  if abs(vb-va)>1e-8:
   for cut in [3.2,10,16]:
    t=(cut-va)/(vb-va)
    if 0<t<1:xs.append(t*ll)
  xs=sorted(set(xs))
  for l,r in zip(xs,xs[1:]):
   aps=sorted([op for op in apertures if op[0]<(l+r)/2<op[1]],key=lambda x:x[2]);z=0
   for op in aps:
    if op[2]>z:wall.face([p(l,0,z),p(r,0,z),p(r,0,op[2]),p(l,0,op[2])],plaster)
    z=op[3]
   wall.face([p(l,0,z),p(r,0,z),p(r,0,rh(*p(r,0,0)[:2])),p(l,0,rh(*p(l,0,0)[:2]))],plaster)
  for l,r,lo,hi,door in apertures:
   c=(l+r)/2;w=r-l;d=.43 if door else .22
   bx(entry if door else windows,c,-d,(lo+hi)/2,w,.06,hi-lo,timber if door else glass)
   for ss in [l,r]:wall.face([p(ss,0,lo),p(ss,-d,lo),p(ss,-d,hi),p(ss,0,hi)],trimat)
   for zz in [lo,hi]:wall.face([p(l,0,zz),p(r,0,zz),p(r,-d,zz),p(l,-d,zz)],trimat)
   for ss in [l-.055,r+.055]:bx(windows,ss,.005,(lo+hi)/2,.11,.16,hi-lo+.14,trimat)
   bx(windows,c,.035,hi+.08,w+.26,.24,.16,trimat)
   if not door:
    bx(windows,c,.04,lo-.07,w+.28,.26,.14,trimat);bx(windows,c,-d+.05,(lo+hi)/2,.045,.05,hi-lo,trimat);bx(windows,c,-d+.05,(lo+hi)/2,w,.05,.05,trimat)
   else:
    bx(entry,c,.31,.015,w+.25,.94,.13,stone)
    for zz in [.65,1.5,2.5]:
     for ss in [c-.34,c+.34]:bx(entry,ss,-.365,zz,.52,.04,.54,panel)
    bx(entry,c+.51,-.33,1.25,.055,.08,.26,iron)
    bx(details,c,.32,3.73,w+.58,.9,.24,trimat)
    # Estimated plain Doric columns outside the clear doorway width.
    for ss in [l-.30,r+.30]:
     x,y,z=p(ss,.35,-.05)
     details.lathe(x,y,z,[(.18,0),(.18,.27),(.14,.33),(.13,3.48),(.21,3.53),(.21,3.66)],trimat,12)
    entrances.append({'name':'Estimated195 Queen Gate street entrance','threshold_xyz':p(c,0,.08),'outward_normal':[nx,ny,0],'clear_width_m':1.4,'door_leaf_xyz':p(c,-.43,1.74),'door_leaf_depth_m':.4,'estimated':True,'supporting_surface':'finite authored threshold .08m; precise step/entrance arrangement unverified'})
  if ei==0:
   bx(details,ll/2,.44,4.03,ll-.3,.95,.16,trimat)
   bx(details,ll/2,.86,4.68,ll-.3,.11,.12,trimat)
   for k in range(24):bx(details,.3+(ll-.6)*k/23,.86,4.37,.07,.09,.55,trimat)
   for zz in [4.1,8.1,11.9,15.7,19.2,22.13]:bx(details,ll/2,.025,zz,ll,.20,.20,trimat)
 roof.surface(feature['geometry'],base,plaster)
 obs=[m.done() for m in [wall,roof,windows,details,entry]]
 return {'created':[o.name for o in obs if o],'parameters':{'front_eaves_m':22.2,'main_roof_m':27.8,'rear_roof_m':23.,'full_mapped_outline':True,'facade_confidence':'low: exact195licensedfacade unavailable; pale residential type is neighbourhood analogy'},'interfaces':{'entrances':entrances},'evidence_source_ids':['ea-lidar-composite-2022-tq27ne','va-praefcke-aerial-a-2011'],'uncertainty':['EA131 inset samples median25.320,p9527.886 supports27.8main roof and23rear. Roof break axes/eaves22.2estimated.','Existing licensed186–188/197–200photos actually inspected only as neighbourhood architectural analogy, not misidentified as195. Limitedtargetsearch did not obtain a verified195street photo.','Three-bay six-level pale stucco sash frontage and west entrance are low-confidence editable estimates. London Picture Archive catalogue136183 reports six storeys, attic, Doric porch and first-floor balustrade; archive photograph not used for geometry. Fine ornamental and dormer features omitted.','South194/north196/eastJayMews common walls left blank. One recessed rear lightwell edge has estimated windows; no adjacent footprint merged.','195urban residential is separate from protected campus; neighboring194 remains frozen.','Full-scene ground and doorway clearance remains coordinator review.']}
