"""Locate the checkout independently of a module's depth."""
import os
from pathlib import Path


def repo_root():
    value=os.environ.get('UWM_ROOT')
    if value:return Path(value).expanduser().resolve()
    return Path(__file__).resolve().parents[2]


def legacy_path(relative):
    """Resolve a historical repo-relative 'output/...' path.

    The old output/ tree now lives outside the checkout; its root comes from
    UWM_SOURCE_LEGACY_OUTPUT or "legacy_output" in sources.local.json. Absolute
    paths and paths not under output/ are returned repo-relative as before.
    """
    import json
    path=Path(relative).expanduser()
    if path.is_absolute() or not path.parts or path.parts[0]!='output':
        return path if path.is_absolute() else repo_root()/path
    value=os.environ.get('UWM_SOURCE_LEGACY_OUTPUT')
    config=repo_root()/'sources.local.json'
    if not value and config.exists():
        value=json.loads(config.read_text()).get('legacy_output')
    return (Path(value).expanduser() if value else repo_root()/'output').joinpath(*path.parts[1:])


def agent_src():
    return repo_root() / 'src/urban_geometry/agent'


def authoring_path(relative=''):
    from .storage import Storage
    path=Path(relative)
    if path.parts and path.parts[0]=='src':
        return agent_src().joinpath(*path.parts[1:])
    return Storage.load().assets('south_ken','geometry')/'authoring'/path


def scene_input(scene, *parts):
    from .storage import Storage, within
    return within(Storage.load().assets(scene, 'input'), *parts)
